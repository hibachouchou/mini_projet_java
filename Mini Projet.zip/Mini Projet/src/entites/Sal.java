package entites;

public interface Sal {
public double CalculeSalaire();
}
